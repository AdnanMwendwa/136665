import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.Button
import android.widget.Toast

class ApplianceControlActivity : AppCompatActivity() {

    private var applianceState = false // Represents the current state of the appliance

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_appliance_control)

        val btnToggleAppliance: Button = findViewById(R.id.btnToggleAppliance)

        // Set a click listener for the button
        btnToggleAppliance.setOnClickListener {
            // Toggle the appliance state
            applianceState = !applianceState

            // Update the button text and perform the IoT action (e.g., send a command to the appliance)
            if (applianceState) {
                // If the appliance is turned on
                btnToggleAppliance.text = "Turn Off Appliance"
                // Send the command to turn on the appliance (implement this part)
                sendApplianceCommand(true)
            } else {
                // If the appliance is turned off
                btnToggleAppliance.text = "Turn On Appliance"
                // Send the command to turn off the appliance (implement this part)
                sendApplianceCommand(false)
            }

            // Provide feedback to the user
            val applianceStatus = if (applianceState) "on" else "off"
            Toast.makeText(
                this,
                "Appliance is now $applianceStatus",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun sendApplianceCommand(turnOn: Boolean) {
        // Implement the code to send the IoT command to control the appliance
        // You may need to interact with your IoT platform or devices here
        // For example, you might send a command to a smart plug or appliance control system
    }
}

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class LogInActivity : AppCompatActivity() {

    // In a real application, this should be securely stored on a server.
    private val secretOTP = Random.nextInt(1000, 9999).toString()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername: EditText = findViewById(R.id.etUsername)
        val etPassword: EditText = findViewById(R.id.etPassword)
        val etOTP: EditText = findViewById(R.id.etOTP)
        val btnLogin: Button = findViewById(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val username = etUsername.text.toString()
            val password = etPassword.text.toString()
            val otp = etOTP.text.toString()

            if (username.isNotEmpty() && password.isNotEmpty() && otp == secretOTP) {
                // OTP is valid; proceed with login.
                // In a real app, you would perform server-side validation and check against a secure 2FA service.
                // If everything is valid, navigate to the MainActivity.
                Toast.makeText(this, "Login Successful!", Toast.LENGTH_SHORT).show()
                // Start the MainActivity here.
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish() // This finishes the current login activity to prevent going back with the back button.
            } else {
                Toast.makeText(this, "Login Failed. Check your credentials and OTP.", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
